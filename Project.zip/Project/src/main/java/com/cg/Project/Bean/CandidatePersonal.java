package com.cg.Project.Bean;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.NotEmpty;

@XmlRootElement
@Entity
@Table(name="candidate_personal")
public class CandidatePersonal {
   
	
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_purchase_id",allocationSize=1000)
	
    private Long candidate;
	private int c=(int) Math.log(candidate);
	//System.out.println(candidateId);
	@Id
	@Column(name="candidate_id")
	private String candidateId="c";
	
	@NotEmpty(message="Name is Mandatory")
	@Pattern(regexp="[A-Za-z]{3,15}",message="Name Sould contain 3 and max 15 letters")
    @Column(name="candidate_name")
    private String candidateName;
	@NotEmpty(message="address is Mandatory")
    @Column(name="address")
    private String address;
    @Column(name="dob")
    private Date dob;
    @Column(name="email_id")
    private String emailId;
    @NotEmpty(message="contact_number is Mandatory")
    @Pattern(regexp="[0-9]{10}",message="contact_number Sould contain 10 numbers")
    @Column(name="contact_number")
    private String contactNumber;
    @NotEmpty(message="marital_status is Mandatory")
    @Column(name="marital_status")
    private String maritalStatus;
    @NotEmpty(message="gender is Mandatory")
    @Column(name="gender")
    private String gender;
    @NotEmpty(message="passport_number is Mandatory")
    @Column(name="passport_number")
    private String passportNumber;


    public CandidatePersonal() {
        super();

    }

    public CandidatePersonal(String candidateId, String candidateName,
            String address, Date dob, String emailId, String contactNumber,
            String maritalStatus, String gender, String passportNumber) {
        super();
        this.candidateId = candidateId;
        this.candidateName = candidateName;
        this.address = address;
        this.dob = dob;
        this.emailId = emailId;
        this.contactNumber = contactNumber;
        this.maritalStatus = maritalStatus;
        this.gender = gender;
        this.passportNumber = passportNumber;

    }

    public String getCandidateId() {
        return candidateId;
    }
    public void setCandidateId(String candidateId) {
        this.candidateId = candidateId;
    }
    public String getCandidateName() {
        return candidateName;
    }
    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public Date getDob() {
        return dob;
    }
    public void setDob(Date dob) {
        this.dob = dob;
    }
    public String getEmailId() {
        return emailId;
    }
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    public String getContactNumber() {
        return contactNumber;
    }
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }
    public String getMaritalStatus() {
        return maritalStatus;
    }
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getPassportNumber() {
        return passportNumber;
    }
    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }


    @Override
    public String toString() {
        return "Candidate_Personal [candidateId=" + candidateId
                + ", candidateName=" + candidateName + ", address=" + address
                + ", dob=" + dob + ", emailId=" + emailId + ", contactNumber="
                        + contactNumber + ", maritalStatus=" + maritalStatus
                        + ", gender=" + gender + ", passportNumber=" + passportNumber
                        +  "]";
    }



}