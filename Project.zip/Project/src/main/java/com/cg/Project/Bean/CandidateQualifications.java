package com.cg.Project.Bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.NotEmpty;
@XmlRootElement
@Entity
@Table(name="candidate_qualifications")
public class CandidateQualifications {
	@Id
    @Column(name="qualification_id")
	
    private String qualificationId;
	@NotEmpty(message="qualification_name is Mandatory")
	@Pattern(regexp="[A-Za-z]{3,15}",message="qualification_name Should contain 3 and max 15 letters")
    @Column(name="qualification_name")
    private String qualificationName;
	@NotEmpty(message="specialization_area is Mandatory")
	@Pattern(regexp="[A-Za-z]{3,15}",message="specialization_area Should contain 3 and max 15 letters")
    @Column(name="specialization_area")
    private String specializationArea;
	@NotEmpty(message="college_name is Mandatory")
	@Pattern(regexp="[A-Za-z]{3,15}",message="college_name Should contain 3 and max 15 letters")
    @Column(name="college_name")
    private String collegeName;
	@NotEmpty(message="university_name is Mandatory")
	@Pattern(regexp="[A-Za-z]{3,15}",message="university_name Should contain 3 and max 15 letters")
    @Column(name="university_name")
    private String universityName;
	@NotEmpty(message="year_of_passing is Mandatory")
	@Pattern(regexp="[0-9]{4}",message="year_of_passing Should contain year in the format YYYY")
    @Column(name="year_of_passing")
    private String yearOfpassing;
	@NotNull(message="percentage is Mandatory")
	@Pattern(regexp="[0-9]{2}",message="percentage Should a number between 10 and 99")

    @Column(name="percentage")
    private double percentage;
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_purchase_id",allocationSize=1)

    @Column(name="candidate_id")
    private String candidateId1;
    public CandidateQualifications(String qualificationId,
            String qualificationName, String specializationArea,
            String collegeName, String universityName, String yearOfpassing,
            double percentage, String candidateId1) {
        super();
        this.qualificationId = qualificationId;
        this.qualificationName = qualificationName;
        this.specializationArea = specializationArea;
        this.collegeName = collegeName;
        this.universityName = universityName;
        this.yearOfpassing = yearOfpassing;
        this.percentage = percentage;
        this.candidateId1 = candidateId1;
    }
   
    public CandidateQualifications() {
        super();
    }
    @Override
    public String toString() {
        return "CandidateQualifications [qualificationId=" + qualificationId
                + ", qualificatioName=" + qualificationName
                + ", specializationArea=" + specializationArea
                + ", collegeName=" + collegeName + ", universityName="
                + universityName + ", yearOfpassing=" + yearOfpassing
                + ", percentage=" + percentage + ", candidateId=" + candidateId1
                + "]";
    }
    public String getQualificationId() {
        return qualificationId;
    }
    public void setQualificationId(String qualificationId) {
        this.qualificationId = qualificationId;
    }
    public String getQualificationName() {
        return qualificationName;
    }
    public void setQualificationName(String qualificatioName) {
        this.qualificationName = qualificatioName;
    }
    public String getSpecializationArea() {
        return specializationArea;
    }
    public void setSpecializationArea(String specializationArea) {
        this.specializationArea = specializationArea;
    }
    public String getCollegeName() {
        return collegeName;
    }
    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }
    public String getUniversityName() {
        return universityName;
    }
    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }
    public String getYearOfpassing() {
        return yearOfpassing;
    }
    public void setYearOfpassing(String yearOfpassing) {
        this.yearOfpassing = yearOfpassing;
    }
    public double getPercentage() {
        return percentage;
    }
    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
    public String getCandidateId() {
        return candidateId1;
    }
    public void setCandidateId(String candidateId1) {
        this.candidateId1 = candidateId1;
    }
    
    

}