package com.cg.Project.Service;


import java.util.List;



















import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Project.Bean.Candidate;
import com.cg.Project.Bean.CandidatePersonal;
import com.cg.Project.Bean.CandidateQualifications;
import com.cg.Project.Bean.CandidateWorkHistory;
import com.cg.Project.Bean.JobApplied;
import com.cg.Project.Bean.JobRequirements;
import com.cg.Project.Dao.CandidatePersonalDAO;
import com.cg.Project.Dao.CandidateQualificationsDAO;
import com.cg.Project.Dao.CandidateWorkHistoryDAO;
import com.cg.Project.Dao.JobAppliedDao;
import com.cg.Project.Dao.JobRequirementsDao;



@Service

public class CandidateServiceImpl implements CandidateService {
	
	@Autowired
	CandidatePersonalDAO cpdao;
	@Autowired
	CandidateQualificationsDAO cqdao;
	@Autowired
	CandidateWorkHistoryDAO cwkdao;
	@Autowired
	JobRequirementsDao jdao;
	@Autowired
	JobAppliedDao jao;
	
	/*// Search for jobs based on qualification, position, years of experience,location
	@Override
	public ArrayList<JobRequirements> findBy(String qualification,
			String position, int experience,String location) {
		
          
            return jdao.findBy(qualification,position,experience,location);
       
	}*/
	

	
	
	
	//Apply for job
	@Override
	public int applyForJob(JobApplied job)
			 {
		jao.save(job);
		return 1;
	}
	

	
	//Candidate to get job requirements of the company
	@Override
	public List<JobRequirements> getJobRequirements()
			 {
		// TODO Auto-generated method stub
		return  jdao.findAll();
	}

	@Override
	public String addResumep(CandidatePersonal p) {
	
	
	cpdao.save(p);
	
	return "CandidatePersonal Added";
	
		
	}
	

	@Override
	public String addResumeq(CandidateQualifications q) {
	
		cqdao.save(q);
	
		return "CandidateQualifications Added";
	
	}
	@Override
	public String addResumew(CandidateWorkHistory w) {

		
		cwkdao.save(w);
	
		return "CandidateWorkHistory Added";
	}
	

	@Override
	public String modifyResumep(CandidatePersonal candidate,String candidateId) {
		// TODO Auto-generated method stub
		if(cpdao.existsById(candidateId)){
			 cpdao.save(candidate);
			// cqdao.save(candidate.getCandidateQualifications());
			// cwkdao.save(candidate.getCandidateWorkHistory());
}
	else{
return "CandidatePersonal details does not exists";
	}
		return "CandidatePersonal updated";
	}

	@Override
	public String modifyResumeq(CandidateQualifications e, String candidateId) {
		if(cpdao.existsById(candidateId)){
			 cqdao.save(e);
			// cqdao.save(candidate.getCandidateQualifications());
			// cwkdao.save(candidate.getCandidateWorkHistory());
}
	else{
return "CandidateQualifications details does not exists";
	}
		return "CandidateQualifications updated";
	}

	@Override
	public String modifyResumew(CandidateWorkHistory e, String candidateId) {
		if(cpdao.existsById(candidateId)){
			 cwkdao.save(e);
			// cqdao.save(candidate.getCandidateQualifications());
			// cwkdao.save(candidate.getCandidateWorkHistory());
}
	else{
return "CandidateWorkHistory details does not exists";
	}
		return "CandidateWorkHistory updated";
	}






	

}
